package Datos;

import Modelo.Alumnos;
import Modelo.Tutores;

import java.sql.*;
import java.util.List;

public class Main {
    public static void main(String[] args) throws SQLException {
        TutoresDAO tutoresDAO = new TutoresDAO();
 
    }
}
