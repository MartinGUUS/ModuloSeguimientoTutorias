Primero correr el script de la bd "TutoriasSQL" para el correcto funcionamiento de la aplicación 

-Solo la primera alumna tiene materias como para hacer su reporte completo